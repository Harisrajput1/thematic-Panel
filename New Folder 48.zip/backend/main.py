from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import uuid

app = FastAPI()

servers = {}

class ServerCreate(BaseModel):
    name: str

@app.get("/api/servers")
def list_servers():
    return list(servers.values())

@app.post("/api/servers")
def create_server(server: ServerCreate):
    server_id = str(uuid.uuid4())
    servers[server_id] = {
        "id": server_id,
        "name": server.name,
        "status": "stopped"
    }
    return servers[server_id]

@app.post("/api/servers/{server_id}/start")
def start_server(server_id: str):
    if server_id in servers:
        servers[server_id]["status"] = "running"
        return {"status": "started"}
    raise HTTPException(status_code=404, detail="Server not found")

@app.post("/api/servers/{server_id}/stop")
def stop_server(server_id: str):
    if server_id in servers:
        servers[server_id]["status"] = "stopped"
        return {"status": "stopped"}
    raise HTTPException(status_code=404, detail="Server not found")