import { useState, useEffect } from "react";

export default function App() {
  const [servers, setServers] = useState([]);
  const [name, setName] = useState("");

  useEffect(() => {
    fetch("/api/servers")
      .then(res => res.json())
      .then(data => setServers(data))
      .catch(err => console.error(err));
  }, []);

  const handleStart = id => {
    fetch(`/api/servers/${id}/start`, { method: "POST" });
  };

  const handleStop = id => {
    fetch(`/api/servers/${id}/stop`, { method: "POST" });
  };

  const handleCreate = () => {
    fetch(`/api/servers`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name })
    }).then(() => window.location.reload());
  };

  return (
    <div className="p-4">
      <input value={name} onChange={e => setName(e.target.value)} placeholder="Server Name" />
      <button onClick={handleCreate}>Create Server</button>
      <div>
        {servers.map(server => (
          <div key={server.id}>
            <h2>{server.name}</h2>
            <p>Status: {server.status}</p>
            <button onClick={() => handleStart(server.id)}>Start</button>
            <button onClick={() => handleStop(server.id)}>Stop</button>
          </div>
        ))}
      </div>
    </div>
  );
}