from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from pydantic import BaseModel
import uuid

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

users_db = {"admin": {"username": "admin", "password": "admin"}}
servers = {}

class ServerCreate(BaseModel):
    name: str

@app.post("/token")
async def login(form_data: OAuth2PasswordRequestForm = Depends()):
    user = users_db.get(form_data.username)
    if user and form_data.password == user["password"]:
        return {"access_token": form_data.username, "token_type": "bearer"}
    raise HTTPException(status_code=400, detail="Invalid credentials")

@app.get("/api/servers")
def list_servers(token: str = Depends(oauth2_scheme)):
    return list(servers.values())

@app.post("/api/servers")
def create_server(server: ServerCreate, token: str = Depends(oauth2_scheme)):
    server_id = str(uuid.uuid4())
    servers[server_id] = {"id": server_id, "name": server.name, "status": "stopped", "owner": token}
    return servers[server_id]

@app.post("/api/servers/{server_id}/start")
def start_server(server_id: str, token: str = Depends(oauth2_scheme)):
    if server_id in servers:
        servers[server_id]["status"] = "running"
        return {"status": "started"}
    raise HTTPException(status_code=404, detail="Server not found")

@app.post("/api/servers/{server_id}/stop")
def stop_server(server_id: str, token: str = Depends(oauth2_scheme)):
    if server_id in servers:
        servers[server_id]["status"] = "stopped"
        return {"status": "stopped"}
    raise HTTPException(status_code=404, detail="Server not found")