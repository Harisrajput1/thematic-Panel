import { useState, useEffect } from "react";

export default function App() {
  const [servers, setServers] = useState([]);
  const [name, setName] = useState("");
  const [token, setToken] = useState(localStorage.getItem("token") || "");
  const [loginForm, setLoginForm] = useState({ username: "", password: "" });

  const fetchServers = () => {
    fetch("http://localhost:8000/api/servers", {
      headers: { Authorization: `Bearer ${token}` }
    })
      .then(res => res.json())
      .then(data => setServers(data))
      .catch(console.error);
  };

  useEffect(() => {
    if (token) fetchServers();
  }, [token]);

  const handleStart = id => {
    fetch(`http://localhost:8000/api/servers/${id}/start`, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}` }
    }).then(fetchServers);
  };

  const handleStop = id => {
    fetch(`http://localhost:8000/api/servers/${id}/stop`, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}` }
    }).then(fetchServers);
  };

  const handleCreate = () => {
    fetch("http://localhost:8000/api/servers", {
      method: "POST",
      headers: { 
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify({ name })
    }).then(fetchServers);
  };

  const login = () => {
    const formData = new URLSearchParams();
    formData.append("username", loginForm.username);
    formData.append("password", loginForm.password);

    fetch("http://localhost:8000/token", {
      method: "POST",
      body: formData
    })
      .then(res => res.json())
      .then(data => {
        setToken(data.access_token);
        localStorage.setItem("token", data.access_token);
        fetchServers();
      });
  };

  if (!token) {
    return (
      <div>
        <input placeholder="Username" onChange={e => setLoginForm({...loginForm, username: e.target.value})} />
        <input type="password" placeholder="Password" onChange={e => setLoginForm({...loginForm, password: e.target.value})} />
        <button onClick={login}>Login</button>
      </div>
    );
  }

  return (
    <div className="p-4">
      <input value={name} onChange={e => setName(e.target.value)} placeholder="Server Name" />
      <button onClick={handleCreate}>Create Server</button>
      <div>
        {servers.map(server => (
          <div key={server.id}>
            <h2>{server.name}</h2>
            <p>Status: {server.status}</p>
            <button onClick={() => handleStart(server.id)}>Start</button>
            <button onClick={() => handleStop(server.id)}>Stop</button>
          </div>
        ))}
      </div>
    </div>
  );
}